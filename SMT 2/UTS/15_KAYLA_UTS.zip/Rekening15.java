public class Rekening15 {
    public static int length;
    String noRekening, nama, namaIbu, phone, email;

    Rekening15(String a, String b, String c, String d, String e) {
        noRekening = a;
        nama = b;
        namaIbu = c;
        phone = d;
        email = e;
    }
}