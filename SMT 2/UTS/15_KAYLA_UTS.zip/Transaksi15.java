
public class Transaksi15 {
    double saldo, saldoAwal, saldoAkhir;
    String tanggalTransaksi, type;

    Transaksi15(double a, double b, double c, String d, String e) {
        saldo = a;
        saldoAwal = b;
        saldoAkhir = c;
        tanggalTransaksi = d;
        type = e;
    }
}